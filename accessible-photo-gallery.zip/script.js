function highlight(image) {
    image.parentElement.style.borderColor = '#007acc';
    console.log("Image focused or hovered");
}

function unhighlight(image) {
    image.parentElement.style.borderColor = 'transparent';
    console.log("Image unfocused or mouse left");
}

function addTabIndex() {
    const figures = document.querySelectorAll("figure");
    for (let i = 0; i < figures.length; i++) {
        figures[i].setAttribute("tabindex", "0");
        console.log("Tab index added to figure:", i);
    }
}
